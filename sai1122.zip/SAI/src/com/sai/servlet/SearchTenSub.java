package com.sai.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.json.simple.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class SearchTenSub {
	
	static String statName[] = new String[10]; 
	static String lastSub = "";
	
	public static JSONObject search(double mapX, double mapY) {
		
		System.out.println("\n ## -----SearchTenSub클래스로 진입함");
		
		JSONObject result = new JSONObject();
		//JSONObject place = new JSONObject();
		
		try{

			String locURL = "http://swopenapi.seoul.go.kr/api/subway/5947735178616c77393747474d664c/xml/nearBy/0/10/" + mapX + "/" + mapY;

			DocumentBuilderFactory dbFactoty = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactoty.newDocumentBuilder();
			Document doc = dBuilder.parse(locURL);

			doc.getDocumentElement().normalize();

			NodeList nList = doc.getElementsByTagName("row");

			for(int i = 0; i < nList.getLength(); i++){
				Node nNode = nList.item(i);
				if(nNode.getNodeType() == Node.ELEMENT_NODE){

					Element eElement = (Element) nNode;

					NodeList statnNm = eElement.getElementsByTagName("statnNm").item(0).getChildNodes();
					Node statnNmInfo = (Node) statnNm.item(0);
					String state = statnNmInfo.getNodeValue();

					NodeList subwayNm = eElement.getElementsByTagName("subwayNm").item(0).getChildNodes();
					Node subwayNmInfo = (Node) subwayNm.item(0);
					String subway = subwayNmInfo.getNodeValue();

					NodeList subwayXcnts = eElement.getElementsByTagName("subwayXcnts").item(0).getChildNodes();
					Node subwayXcntsInfo = (Node) subwayXcnts.item(0);
					String subwayX = subwayXcntsInfo.getNodeValue();

					NodeList subwayYcnts = eElement.getElementsByTagName("subwayYcnts").item(0).getChildNodes();
					Node subwayYcntsInfo = (Node) subwayYcnts.item(0);
					String subwayY = subwayYcntsInfo.getNodeValue();

					//역 10개 배열에 삽입
					statName[i] = state;
				}
				
				System.out.println("statName" + i + " : " + statName[i]);
			}

			System.out.println("\n####-------SearchTenSub  ::: Chooselast에서 오기전 ");
			lastSub = ChooseLastSub.getTotalTime();
			
			System.out.println("\n####-------SearchTenSub  ::: Chooselast에서 lastSub옴 ::  " + lastSub);

			
			
			result = SearchLastSubPath.findPath(lastSub);
			
			System.out.println("다시 SearchTenSub로 들어와서 결과 출력 : " + result.toJSONString());
			
			//place = SearchMiddlePlace.getHotPlace();
			
		} catch (Exception e){   
			e.printStackTrace();
		}
		//성공
		return result; //!결과값이랑 플레이스 목록이 같이 리턴되어야 함.
	} 
}
