package com.sai.vo;

public class MemberVO{
	private String MEMBER_PHOTO;
	private String MEMBER_ID;
	private String MEMBER_PW;
	private String MEMBER_NAME;
	private String MEMBER_PHONE;
	private String MEMBER_STATION;
	
	public String getMEMBER_PHOTO() {
		return MEMBER_PHOTO;
	}
	
	public void setMEMBER_PHOTO(String memberPhoto) {
		MEMBER_PHOTO = memberPhoto;
	}
	
	public String getMEMBER_ID() {
		return MEMBER_ID;
	}
	
	public void setMEMBER_ID(String memberId) {
		MEMBER_ID = memberId;
	}
	
	public String getMEMBER_PW() {
		return MEMBER_PW;
	}

	public void setMEMBER_PW(String memberPw) {
		MEMBER_PW = memberPw;
	}

	public String getMEMBER_NAME() {
		return MEMBER_NAME;
	}

	public void setMEMBER_NAME(String memberName) {
		MEMBER_NAME = memberName;
	}

	public String getMEMBER_PHONE() {
		return MEMBER_PHONE;
	}

	public void setMEMBER_PHONE(String memberPhone) {
		MEMBER_PHONE = memberPhone;
	}

	public String getMEMBER_STATION() {
		return MEMBER_STATION;
	}

	public void setMEMBER_STATION(String memberStation) {
		MEMBER_STATION = memberStation;
	}
	
}
